import os
import sys
import webbrowser
import threading
import time
import uvicorn

def open_browser():
    time.sleep(1.5)
    print("Opening browser at http://127.0.0.1:8000 ...")
    webbrowser.open("http://127.0.0.1:8000")

if __name__ == "__main__":
    print("=" * 60)
    print("CyberShield AI - Network Intrusion Detection System")
    print("Starting FastAPI Server at http://127.0.0.1:8000")
    print("API Docs: http://127.0.0.1:8000/docs")
    print("Press CTRL+C to stop.")
    print("=" * 60)
    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=False, log_level="info")
