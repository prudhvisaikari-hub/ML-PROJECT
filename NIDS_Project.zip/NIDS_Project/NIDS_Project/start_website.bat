@echo off
title CyberShield AI - Network Intrusion Detection System
echo Starting NIDS Web Server...
cd /d "%~dp0"
python run_server.py
pause
