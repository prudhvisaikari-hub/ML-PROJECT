import os, json, time
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd
import joblib
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")
WEBSITE_DIR = os.path.join(BASE_DIR, "website")

app = FastAPI(
    title="CyberShield AI - Network Intrusion Detection API",
    description="REST API for real-time Network Intrusion Detection using Random Forest and HistGradientBoosting classifiers trained on the CIC-IDS2017 benchmark dataset.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global model caches
rf_model = None
gb_model = None
meta = None
results_data = None
feature_defaults = {}

def get_threat_severity(attack_type: str) -> Dict[str, str]:
    if attack_type == "BENIGN":
        return {
            "risk": "SAFE",
            "color": "emerald",
            "action": "Normal network traffic. No mitigation required."
        }
    high_threats = ["DDoS", "DoS Hulk", "PortScan", "Bot"]
    if attack_type in high_threats:
        return {
            "risk": "CRITICAL",
            "color": "rose",
            "action": f"Immediate intrusion response: Drop traffic from source IP, enforce rate-limiting, and update edge firewall rules."
        }
    if "Patator" in attack_type or "Web Attack" in attack_type:
        return {
            "risk": "HIGH",
            "color": "amber",
            "action": f"Suspicious brute-force / application exploit: Restrict login attempts, rotate credentials, and block abusive subnet."
        }
    return {
        "risk": "MEDIUM",
        "color": "orange",
        "action": f"Abnormal flow pattern: Log flow metadata and monitor host telemetry for lateral movement."
    }

@app.on_event("startup")
def load_artifacts():
    global rf_model, gb_model, meta, results_data, feature_defaults
    print("Loading models and metadata...")
    rf_path = os.path.join(MODELS_DIR, "rf_model.joblib")
    gb_path = os.path.join(MODELS_DIR, "gb_model.joblib")
    meta_path = os.path.join(MODELS_DIR, "metadata.joblib")
    results_path = os.path.join(WEBSITE_DIR, "results.json")
    
    if os.path.exists(rf_path):
        rf_model = joblib.load(rf_path)
    if os.path.exists(gb_path):
        gb_model = joblib.load(gb_path)
    if os.path.exists(meta_path):
        meta = joblib.load(meta_path)
        # Initialize default median feature vector
        for f in meta.get("features", []):
            feature_defaults[f] = 0.0
    if os.path.exists(results_path):
        with open(results_path, "r", encoding="utf-8") as f:
            results_data = json.load(f)
            
    print("Models and metadata successfully loaded.")

class PredictRequest(BaseModel):
    features: Dict[str, float]

@app.get("/")
def get_index():
    index_file = os.path.join(WEBSITE_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file, media_type="text/html")
    return {"message": "CyberShield NIDS API is running. Website index not found."}

@app.get("/api/results")
def get_results():
    if results_data is None:
        results_path = os.path.join(WEBSITE_DIR, "results.json")
        if os.path.exists(results_path):
            with open(results_path, "r", encoding="utf-8") as f:
                return json.load(f)
        raise HTTPException(status_code=404, detail="Results data not found.")
    return results_data

@app.get("/api/stats")
def get_stats():
    return {
        "status": "online",
        "models": {
            "random_forest": rf_model is not None,
            "gradient_boosted": gb_model is not None
        },
        "feature_count": len(meta["features"]) if meta else 0,
        "classes": meta["classes"] if meta else []
    }

@app.post("/api/predict")
def predict_flow(req: PredictRequest):
    if rf_model is None or gb_model is None or meta is None:
        raise HTTPException(status_code=503, detail="Models are not loaded.")
        
    feature_names = meta["features"]
    
    # Fill feature vector in exact training order
    row_values = []
    for col in feature_names:
        # Match case-insensitively or stripped
        val = req.features.get(col)
        if val is None:
            # try fuzzy match
            matched = False
            for k, v in req.features.items():
                if k.strip().lower() == col.strip().lower():
                    val = v
                    matched = True
                    break
            if not matched:
                val = feature_defaults.get(col, 0.0)
        try:
            val = float(val)
            if np.isnan(val) or np.isinf(val):
                val = 0.0
        except (ValueError, TypeError):
            val = 0.0
        row_values.append(val)
        
    df_row = pd.DataFrame([row_values], columns=feature_names)
    
    t0 = time.time()
    rf_pred = str(rf_model.predict(df_row)[0])
    rf_time_ms = round((time.time() - t0) * 1000, 2)
    
    # Random Forest Probabilities
    rf_conf = 0.99
    try:
        rf_proba = rf_model.predict_proba(df_row)[0]
        rf_classes = list(rf_model.classes_)
        rf_conf = round(float(rf_proba[rf_classes.index(rf_pred)]), 4)
    except Exception:
        pass
        
    t0 = time.time()
    gb_pred = str(gb_model.predict(df_row)[0])
    gb_time_ms = round((time.time() - t0) * 1000, 2)
    
    gb_conf = 0.98
    try:
        gb_proba = gb_model.predict_proba(df_row)[0]
        gb_classes = list(gb_model.classes_)
        gb_conf = round(float(gb_proba[gb_classes.index(gb_pred)]), 4)
    except Exception:
        pass
        
    # Consensus verdict
    consensus = rf_pred if rf_conf >= gb_conf else gb_pred
    severity = get_threat_severity(consensus)
    
    return {
        "verdict": consensus,
        "is_attack": consensus != "BENIGN",
        "risk_level": severity["risk"],
        "recommended_action": severity["action"],
        "models": {
            "Random Forest": {
                "prediction": rf_pred,
                "is_attack": rf_pred != "BENIGN",
                "confidence": rf_conf,
                "latency_ms": rf_time_ms
            },
            "Gradient-Boosted Trees": {
                "prediction": gb_pred,
                "is_attack": gb_pred != "BENIGN",
                "confidence": gb_conf,
                "latency_ms": gb_time_ms
            }
        }
    }

@app.post("/api/predict-batch")
async def predict_batch(file: UploadFile = File(...)):
    if rf_model is None or gb_model is None or meta is None:
        raise HTTPException(status_code=503, detail="Models are not loaded.")
        
    try:
        df_upload = pd.read_csv(file.file, low_memory=False, encoding="latin1")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse CSV file: {str(e)}")
        
    df_upload.columns = df_upload.columns.str.strip()
    
    # Store original labels if available
    has_labels = "Label" in df_upload.columns or "Actual_Label" in df_upload.columns
    actual_col = "Label" if "Label" in df_upload.columns else ("Actual_Label" if "Actual_Label" in df_upload.columns else None)
    actuals = df_upload[actual_col].tolist() if actual_col else []
    
    feature_names = meta["features"]
    
    # Align features
    aligned_rows = []
    for _, row in df_upload.iterrows():
        r_vals = []
        for col in feature_names:
            v = row.get(col, 0.0)
            try:
                v = float(v)
                if np.isnan(v) or np.isinf(v):
                    v = 0.0
            except:
                v = 0.0
            r_vals.append(v)
        aligned_rows.append(r_vals)
        
    X_input = pd.DataFrame(aligned_rows, columns=feature_names)
    
    t0 = time.time()
    rf_preds = rf_model.predict(X_input)
    gb_preds = gb_model.predict(X_input)
    elapsed_ms = round((time.time() - t0) * 1000, 2)
    
    total = len(df_upload)
    threat_breakdown = {}
    flagged_threats = []
    
    for i in range(total):
        rf_p = str(rf_preds[i])
        gb_p = str(gb_preds[i])
        consensus = rf_p  # primary
        
        threat_breakdown[consensus] = threat_breakdown.get(consensus, 0) + 1
        
        if consensus != "BENIGN":
            sev = get_threat_severity(consensus)
            flagged_threats.append({
                "row_index": i + 1,
                "detected_attack": consensus,
                "rf_prediction": rf_p,
                "gb_prediction": gb_p,
                "risk_level": sev["risk"],
                "actual_label": actuals[i] if actuals else "Unknown",
                "flow_duration": float(X_input.iloc[i].get("Flow Duration", 0)),
                "dst_port": int(X_input.iloc[i].get("Destination Port", 0)),
                "flow_bytes_per_s": round(float(X_input.iloc[i].get("Flow Bytes/s", 0)), 2)
            })
            
    benign_count = threat_breakdown.get("BENIGN", 0)
    attack_count = total - benign_count
    
    return {
        "total_flows": total,
        "benign_count": benign_count,
        "attack_count": attack_count,
        "attack_percentage": round((attack_count / total * 100), 2) if total > 0 else 0,
        "inference_time_ms": elapsed_ms,
        "breakdown": threat_breakdown,
        "flagged_threats": flagged_threats[:100]  # Return up to 100 flagged flows for display
    }

# Mount static files folder
app.mount("/static", StaticFiles(directory=WEBSITE_DIR), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
