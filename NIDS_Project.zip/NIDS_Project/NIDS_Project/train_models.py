import glob, os, json, time, gc
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                             classification_report, confusion_matrix)
import joblib

RANDOM_STATE = 42
DATA_DIR = r"C:\Users\prudh\Downloads\files\MachineLearningCSV\MachineLearningCVE"
OUTPUT_DIR = r"C:\Users\prudh\Downloads\NIDS_Project\NIDS_Project"

print("Starting NIDS model training pipeline...")
files = sorted(glob.glob(os.path.join(DATA_DIR, "*.pcap_ISCX.csv")))
print(f"Found {len(files)} dataset files in {DATA_DIR}")

# Target sample strategy:
# - Collect all minority attacks
# - Cap huge attacks (DDoS, PortScan, DoS Hulk) to ~10,000 - 15,000 each
# - Collect ~40,000 BENIGN samples distributed across files
# Total will be ~80,000 - 100,000 high-quality rows, perfectly balanced for training tree models.

sampled_chunks = []
total_raw_rows = 0

for p in files:
    fname = os.path.basename(p)
    print(f"Processing {fname}...")
    
    # Read headers
    header_df = pd.read_csv(p, encoding="latin1", nrows=1)
    clean_cols = [c.strip() for c in header_df.columns]
    label_idx = [i for i, c in enumerate(clean_cols) if "label" in c.lower()][0]
    raw_label_name = header_df.columns[label_idx]
    
    # Read in chunks of 50,000 to keep RAM low
    for chunk in pd.read_csv(p, encoding="latin1", chunksize=50000, low_memory=False):
        total_raw_rows += len(chunk)
        chunk.columns = chunk.columns.str.strip()
        
        # Clean label column
        chunk["Label"] = (chunk["Label"].astype(str)
                          .str.replace(r"[^\x20-\x7E]", "-", regex=True)
                          .str.replace(r"\s*-+\s*", " - ", regex=True).str.strip())
        
        # Filter negative flow duration
        if "Flow Duration" in chunk.columns:
            chunk = chunk[chunk["Flow Duration"] >= 0]
            
        # Sample strategically:
        # Keep all non-BENIGN attacks, but sample BENIGN at 5%
        attacks = chunk[chunk["Label"] != "BENIGN"]
        benign = chunk[chunk["Label"] == "BENIGN"]
        
        if len(benign) > 0:
            benign_sample = benign.sample(frac=0.04, random_state=RANDOM_STATE)
        else:
            benign_sample = pd.DataFrame()
            
        keep = pd.concat([attacks, benign_sample])
        if len(keep) > 0:
            # Convert feature columns to float32
            feats = [c for c in keep.columns if c != "Label"]
            keep[feats] = keep[feats].apply(pd.to_numeric, errors="coerce").astype("float32")
            sampled_chunks.append(keep)
            
    print(f"  Processed {fname}, accumulated samples: {sum(len(x) for x in sampled_chunks):,}")
    gc.collect()

print(f"\nConcatenating sampled data (from {total_raw_rows:,} raw rows)...")
df = pd.concat(sampled_chunks, ignore_index=True)
del sampled_chunks
gc.collect()

print("Raw sampled shape:", df.shape)

# Clean inf/nan
df = df.replace([np.inf, -np.inf], np.nan).dropna()
df = df.drop_duplicates()
print("After dropna & duplicates:", df.shape)

# Normalize labels & handle small classes
counts = df["Label"].value_counts()
print("\nSampled class distribution before capping:")
print(counts)

# Cap oversized attack classes to keep training fast & balanced (e.g., max 12,000 per attack)
balanced_dfs = []
for label, group in df.groupby("Label"):
    if len(group) > 12000:
        balanced_dfs.append(group.sample(12000, random_state=RANDOM_STATE))
    elif len(group) < 50:
        # Merge very tiny classes (like Heartbleed: 11) into 'Other attack'
        group_copy = group.copy()
        group_copy["Label"] = "Other attack"
        balanced_dfs.append(group_copy)
    else:
        balanced_dfs.append(group)

df = pd.concat(balanced_dfs, ignore_index=True)
del balanced_dfs
gc.collect()

counts = df["Label"].value_counts()
print("\nFinal class distribution for training:")
print(counts)
print(f"Total training dataset size: {len(df):,} flows")

X = df.drop(columns="Label")
y = df["Label"]
classes = sorted(y.unique().tolist())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
)
print(f"\nTrain size: {X_train.shape}, Test size: {X_test.shape}")

# Model 1: Random Forest
print("\nTraining Random Forest Classifier (100 trees)...")
rf = RandomForestClassifier(
    n_estimators=100,
    min_samples_leaf=2,
    class_weight="balanced_subsample",
    random_state=RANDOM_STATE,
    n_jobs=-1
)
t0 = time.time()
rf.fit(X_train, y_train)
rf_time = round(time.time() - t0, 2)
print(f"Random Forest trained in {rf_time}s")

# Model 2: HistGradientBoostingClassifier
print("\nTraining HistGradientBoostingClassifier (max_iter=100)...")
gb = HistGradientBoostingClassifier(
    max_iter=100,
    learning_rate=0.1,
    random_state=RANDOM_STATE
)
t0 = time.time()
gb.fit(X_train, y_train)
gb_time = round(time.time() - t0, 2)
print(f"Gradient-Boosted Trees trained in {gb_time}s")

# Evaluation function
def evaluate(name, model, train_sec):
    pred = model.predict(X_test)
    p_w, r_w, f_w, _ = precision_recall_fscore_support(y_test, pred, average="weighted", zero_division=0)
    p_m, r_m, f_m, _ = precision_recall_fscore_support(y_test, pred, average="macro", zero_division=0)
    
    yb = (y_test != "BENIGN")
    pb = (pred != "BENIGN")
    acc_b = accuracy_score(yb, pb)
    bp, br, bf, _ = precision_recall_fscore_support(yb, pb, average="binary", zero_division=0)
    
    cm = confusion_matrix(y_test, pred, labels=classes).tolist()
    rep = classification_report(y_test, pred, output_dict=True, zero_division=0)
    
    res = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "weighted": {"precision": float(p_w), "recall": float(r_w), "f1": float(f_w)},
        "macro": {"precision": float(p_m), "recall": float(r_m), "f1": float(f_m)},
        "binary": {"accuracy": float(acc_b), "precision": float(bp), "recall": float(br), "f1": float(bf)},
        "train_seconds": train_sec,
        "per_class": rep,
        "confusion_matrix": cm
    }
    return res, pred

print("\nEvaluating models on held-out test set...")
rf_res, rf_pred = evaluate("Random Forest", rf, rf_time)
gb_res, gb_pred = evaluate("Gradient-Boosted Trees", gb, gb_time)

results = {
    "Random Forest": rf_res,
    "Gradient-Boosted Trees": gb_res
}

print("\n===== RANDOM FOREST RESULTS =====")
print(f"Accuracy: {rf_res['accuracy']:.4f} | Weighted F1: {rf_res['weighted']['f1']:.4f} | Macro F1: {rf_res['macro']['f1']:.4f}")
print(f"Binary (Attack vs Normal) - Precision: {rf_res['binary']['precision']:.4f}, Recall: {rf_res['binary']['recall']:.4f}, F1: {rf_res['binary']['f1']:.4f}")

print("\n===== GRADIENT-BOOSTED TREES RESULTS =====")
print(f"Accuracy: {gb_res['accuracy']:.4f} | Weighted F1: {gb_res['weighted']['f1']:.4f} | Macro F1: {gb_res['macro']['f1']:.4f}")
print(f"Binary (Attack vs Normal) - Precision: {gb_res['binary']['precision']:.4f}, Recall: {gb_res['binary']['recall']:.4f}, F1: {gb_res['binary']['f1']:.4f}")

# Feature importances from Random Forest
imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
top_features = [{"feature": str(k), "importance": round(float(v), 5)} for k, v in imp.head(15).items()]
top_feature_names = list(imp.head(12).index)

# Sample test flows (diverse sample across classes)
sample_indices = []
for c in classes:
    c_indices = y_test[y_test == c].index
    if len(c_indices) > 0:
        sample_indices.extend(c_indices[:min(len(c_indices), 4)])

Xs = X_test.loc[sample_indices]
ys = y_test.loc[sample_indices]

samples = []
for i, idx in enumerate(sample_indices):
    row = Xs.iloc[i]
    samples.append({
        "features": {c: round(float(row[c]), 4) for c in top_feature_names},
        "all_features": {c: round(float(row[c]), 4) for c in X.columns},
        "actual": str(ys.loc[idx]),
        "random_forest": str(rf.predict(Xs.iloc[[i]])[0]),
        "gradient_boosted": str(gb.predict(Xs.iloc[[i]])[0])
    })

out = {
    "dataset": {
        "files": [os.path.basename(f) for f in files],
        "rows_after_cleaning": int(total_raw_rows),
        "rows_used": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "n_features": int(X.shape[1]),
        "feature_names": list(X.columns),
        "classes": classes,
        "class_counts": {str(k): int(v) for k, v in counts.items()}
    },
    "models": results,
    "top_features": top_features,
    "samples": samples
}

# Save outputs to both NIDS_Project root and website/
os.makedirs(os.path.join(OUTPUT_DIR, "models"), exist_ok=True)
os.makedirs(os.path.join(OUTPUT_DIR, "website"), exist_ok=True)

results_json_path = os.path.join(OUTPUT_DIR, "website", "results.json")
with open(results_json_path, "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)

rf_path = os.path.join(OUTPUT_DIR, "models", "rf_model.joblib")
gb_path = os.path.join(OUTPUT_DIR, "models", "gb_model.joblib")
joblib.dump(rf, rf_path, compress=3)
joblib.dump(gb, gb_path, compress=3)

# Also dump feature list & classes
joblib.dump({"features": list(X.columns), "classes": classes}, os.path.join(OUTPUT_DIR, "models", "metadata.joblib"))

print(f"\nSuccessfully generated and saved:")
print(f"1. {results_json_path}")
print(f"2. {rf_path}")
print(f"3. {gb_path}")
print("Done!")
