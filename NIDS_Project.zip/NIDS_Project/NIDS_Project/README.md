# CyberShield AI · Network Intrusion Detection System (NIDS)

> **Machine Learning-Based Threat Classification on CIC-IDS2017**  
> Comparing **Random Forest** and **Gradient-Boosted Trees (HistGB)** across 2.8 Million Network Flows and 13 Threat Classes.

**Research Team:**
- **Tanya Sri** (2520030112)
- **Prudhvi Sai** (2520030286)

---

## 🌟 Project Overview & Key Highlights

This project implements an end-to-end Machine Learning pipeline and interactive cybersecurity dashboard for real-time Network Intrusion Detection using the benchmark **CIC-IDS2017** dataset.

- **Total Network Flows Processed**: 2,830,743 raw network records across 8 weekday traffic captures.
- **Trained Traffic Profiles**: 13 Classes (`BENIGN`, `DDoS`, `DoS Hulk`, `PortScan`, `DoS GoldenEye`, `FTP - Patator`, `DoS slowloris`, `DoS Slowhttptest`, `SSH - Patator`, `Bot`, `Web Attack - Brute Force`, `Web Attack - XSS`, `Other attack`).
- **Feature Dimension**: 78 statistical TCP/IP flow attributes.
- **Random Forest Accuracy**: **98.78%** | **Weighted F1**: **98.79%** | **Macro F1**: **93.03%**
- **Binary Threat Detection F1**: **99.83%** (Precision: **99.81%**, Recall: **99.85%**)
- **HistGradientBoosting Accuracy**: **98.32%** | **Attack Recall**: **99.92%**
- **Inference Latency**: Sub-millisecond (< 0.5 ms per flow).

---

## 📁 Repository Structure

```
NIDS_Project/
├── app.py                      # Production FastAPI backend for real-time model inference & batch CSV scans
├── run_server.py               # One-click server launcher with automatic browser opening
├── start_website.bat           # Windows 1-click batch launcher
├── train_models.py             # Memory-optimized full training pipeline for CIC-IDS2017
├── docs/
│   └── Project_Abstract.docx   # Academic project abstract and methodology
├── models/
│   ├── rf_model.joblib         # Trained Random Forest classifier (5.0 MB)
│   ├── gb_model.joblib         # Trained HistGradientBoosting classifier (346 KB)
│   └── metadata.joblib         # Serialized feature list and class mappings
├── notebooks/
│   ├── 01_EDA.ipynb            # Exploratory data analysis of Monday baseline traffic
│   └── 02_Train_Models.ipynb   # Colab-ready dual model training and evaluation
└── website/
    ├── index.html              # Modern, glassmorphic cybersecurity dashboard with embedded results
    ├── results.json            # Complete export of all evaluation metrics, matrices, and test flows
    └── sample_test_flows.csv   # Pre-extracted 52-flow test batch for live CSV scanning
```

---

## 🚀 How to Run the Website

### Option 1: Live Interactive Server (Recommended)
Runs the full FastAPI backend with live model inference and real-time scanning:
```powershell
python run_server.py
```
*Or simply double-click `start_website.bat`.*

The application will start at **http://127.0.0.1:8000** and automatically open in your default browser.
- **Interactive UI**: `http://127.0.0.1:8000/`
- **Swagger REST API Docs**: `http://127.0.0.1:8000/docs`

### Option 2: Standalone Offline Mode (Zero Setup)
Because the complete evaluated dataset results are embedded directly into `website/index.html`:
- Double-click `website/index.html` in Windows Explorer to open directly in any browser (Chrome, Edge, Firefox).
- All interactive charts, confusion matrices, per-class metrics, feature importances, and client-side flow simulators work **100% offline without needing any server running**.

---

## 🔬 Model Performance Benchmarks

| Metric | Random Forest (100 Trees) | Gradient-Boosted Trees (HistGB) | Best Model |
| :--- | :---: | :---: | :---: |
| **Overall Accuracy** | **98.78%** | 98.32% | **Random Forest** |
| **Weighted F1-Score** | **98.79%** | 98.45% | **Random Forest** |
| **Macro F1-Score** | **93.03%** | 86.39% | **Random Forest** |
| **Attack Precision (Binary)** | **99.81%** | 99.77% | **Random Forest** |
| **Attack Recall (Binary)** | 99.85% | **99.92%** | **Gradient-Boosted** |
| **Attack F1-Score (Binary)**| **99.83%** | 99.85% | **Tie / Both > 99.8%** |
| **Training Duration** | **2.59 seconds** | 6.61 seconds | **Random Forest** |
| **Model Disk Size** | 5.0 MB | **346 KB** | **Gradient-Boosted** |

---

## 🛡️ Interactive Website Features

1. **Live Traffic Telemetry**: Real-time animated packet monitor showing classified network flows.
2. **Exploratory Data Telemetry (EDA)**: Interactive class distribution bars and findings from 2.8M CIC-IDS2017 flows.
3. **Head-to-Head Benchmark Table**: Comprehensive comparison of Random Forest vs Gradient-Boosted Trees.
4. **Per-Class Metrics**: Interactive tables for Precision, Recall, F1, and Support across all 13 attack categories.
5. **Interactive Normalized Confusion Matrices**: 13x13 heatmap grid with cell hover tooltips for both models.
6. **Explainable AI (Feature Importance)**: Top 15 network traffic features (Destination Port, Window Sizes, Packet Rates) with cybersecurity domain explanations.
7. **Live Threat Simulator**:
   - **Mode 1 - Held-Out Real Test Flows**: Test pre-loaded flows with instant dual-model verdicts.
   - **Mode 2 - Parameter Synthesizer**: Adjust Port, Duration, Bytes/s, Packets/s to test edge-case traffic.
   - **Mode 3 - CSV Batch Scanner**: Upload any flow capture file or use the built-in 52-flow test batch for immediate incident triage and risk reporting.
8. **Theme Toggle**: Seamless dark cyber-defense mode and clean daylight mode.
9. **Project Deliverables Download Center**: Direct downloads for `results.json`, trained weights, and sample test data.

---

## 👥 Authors & Academic Submission
- **Tanya Sri** (Registration No: 2520030112)
- **Prudhvi Sai** (Registration No: 2520030286)
